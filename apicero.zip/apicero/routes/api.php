<?php

use App\Http\Controllers\ApiResponse;
use App\Http\Controllers\ApiSapController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\simpleauth;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
{"name":"","password":""}
header
Authorization: Bearer auth61e4eb19bb6d061e??????

login return json {"access_token":"auth????????"}
*/
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post("/registrar",[simpleauth::class, 'registrar']);//registra  //json keys("name","password")
Route::post("/login",[simpleauth::class, 'login']);//login json keys("name","password")
Route::post("/logout",[simpleauth::class, 'logout'])->middleware("miauth");//cerrar sesion, necesita estar autenticado
Route::get("/sesions",[simpleauth::class,"getSesions"]);//testeo, debe ser quitado luego

//sap login
Route::post("/loginsap",[ApiSapController::class,"login"]);

Route::get("/checksesion",function(Request $request){
    return "sesion iniciada";
})->middleware("miauth");
Route::post("/almacenar",[ApiResponse::class,"almacenar"])->middleware("miauth");

/*Route::get("/checksesion",function(){
    return "Sesion iniciada";
});//testeo*/