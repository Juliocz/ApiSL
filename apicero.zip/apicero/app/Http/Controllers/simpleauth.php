<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use stdClass;

use function PHPUnit\Framework\isEmpty;

class simpleauth extends Controller
{   //nota cuando obtengo de session si tengo instancia del objeto, pero de un json no, ahi debo instanciar
    //para registro y login, solo requiere un json con name y password
    public $users;
    public $timeExpired=1000*60*1000;//30minutos
    public static $coockieTokenName="B1SESSION";
    //public $token;
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {   date_default_timezone_set("America/Argentina/Salta");
        if(session_status() === PHP_SESSION_NONE) session_start();
        if(!isset($_SESSION["users"]))//si la variable users es nulo o aun no fue definida
         $this->users=$_SESSION["users"]=array();
        else
        $this->users=$_SESSION["users"];
        $this->verificarTime();//verifica caducacion de sesiones

    }
    public function __invoke(Request $request)
    { 
    
    }
    public static function getUserAuth(Request $request){
                //obtiene el usuario autenticado, sino devuelve falso
                $auth=new simpleauth();
                //obtengo token en cada constructor
                $token=$request->bearerToken();
                if(!$token)$token=$request->cookie(simpleauth::$coockieTokenName);
                return $auth->isSession($token);
    }

    public function registrar(Request $request){
        //$user=new User($request->name,$request->password);
        $user=new User($request->name,$request->password);
        $user->token=(round(microtime(true) * 1000));
        $usersSaved=$this->getUsersFromtxt();
        if(!$this->isExistinArray($user,$usersSaved))//si aun no esta registrado lo registro
        //if(true)
        {
            array_push($usersSaved,$user);//agrego sesion
        $this->saveUserstoTxt($usersSaved);
        //return $usersSaved[0]->name;
        return "Se registro correctamente";
        }
        else {
            return "No se pudo registrar, o ya existe en el registro";
        //return $usersSaved;
        }
    }
    public function login(Request $request){
        $user=new User($request->name,$request->password);

        //if($user->name=="julio" && $user->password=="123456"){//si existe usuario en bd
        //if(true){//si existe usuario en bd
        if($this->isExistinTxt($user))//aqui aparte de verificar, obtengo el token id guardado en txt
        {
            if($this->isSessionIniciada($user))//si ya inicio session, devuelvo un json con el token y aviso
                return json_encode(array('access_token' => $user->token,"msg" =>"Session ya iniciada anteriormente"));
            else //aun no inicio session, creo token

            
        $user->token="auth".uniqid(uniqid()).$user->token;//asigno token
        $user->timeVencimiento=(round(microtime(true) * 1000))+$this->timeExpired;//30minutos

        
        //array_push($this->users,$user);//agrego sesion
        array_push($_SESSION["users"],$user);//agrego sesion

        
        //aviso que se inicio sesion
        //$this->onLogin($user);
        ApiEvents::onLogin($user,$request);


        
        
        //return $request->all(); //obtiene all body
        //return $request->name;
        //return $user->toJson();
        //return $_SERVER["HTTP_AUTHORIZATION"]+uniqid("");
        //return "auth".uniqid(uniqid());
        //return json_encode(array('access_token' => $user->token));
        return response(json_encode(array('access_token' => $user->token)))->withCookie(
            cookie(self::$coockieTokenName, $user->token, $this->timeExpired)
            );
        }
        else
        return "Usuario no existe";
    }
    public function logout(Request $request){
        $token=$request->bearerToken();//obtengo token del bearer
        if(!$token)$token=$request->cookie(simpleauth::$coockieTokenName);//sino de la coockie
        
        for($i = 0; $i < sizeof($_SESSION["users"]);$i++){
            if($_SESSION["users"][$i]->token==$token){//si el token es igual al token que quiere cerrar sesion
                array_splice($_SESSION["users"], $i, 1);//cierra la sesion
                //return true;
                return "Se cerro la sesion correctamente";
            }
        }
        return "No se pudo cerrar sesion";//si no cerro ninguna cesion
    }



    //verifica si la sesion ya fue iniciada y devuelve el mismo usuario con el token, sino devuelve null
    public function isSessionIniciada(User $user){
        foreach ($_SESSION["users"] as &$usersSesion) {
        //foreach ($this->users as &$usersSesion) {
            if($user->compare($usersSesion)){
                $user->token=$usersSesion->token;
                $user->timeVencimiento=$usersSesion->timeVencimiento;
                return $usersSesion;
            }
        }
        return false;
    }
    public function isExistinTxt(User $user){
        $usersSaved=$this->getUsersFromtxt();//obtengo usuarios del txt
        if($this->isExistinArray($user,$usersSaved))//si esta registrado
        {
        return true;
        }
        else 
            return false;
        //return $usersSaved;
    }
    public static function saveHistorial(User $user,Request $request,$type){
        
            
            if(!file_exists("historial.txt")){
                $fp = fopen("historial.txt","w");
                fclose($fp);
            }
            //obtengo historial
            $fp = fopen("historial.txt","r") or die('[]');
            $json =fgets($fp);
            fclose($fp);
            if(empty($json))$json="[]";

            $historialList=json_decode($json,true);

            //creo historial tipo, peticion y usuario
            $historial=new stdClass();
            $historial->type=$type;
            $historial->peticion=$request->all();
            $historial->user=$user;
            //$historial->date=date(DATE_RFC2822);
            $historial->date=Carbon::now()->toDateTimeString();
            array_push($historialList,$historial);

            //guardo historial
            $fp = fopen("historial.txt","w");//w trunca a 0 longitud
            fwrite($fp,json_encode($historialList));
            fclose($fp);

            return "guardado correctamente";
    }

    public static function saveHistorialwithdate(User $user,$dato,Request $request,$type){
        
            
        if(!file_exists("historial.txt")){
            $fp = fopen("historial.txt","w");
            fclose($fp);
        }
        //obtengo historial
        $fp = fopen("historial.txt","r") or die('[]');
        $json =fgets($fp);
        fclose($fp);
        if(empty($json))$json="[]";

        $historialList=json_decode($json,true);

        //creo historial tipo, peticion y usuario
        $historial=new stdClass();
        $historial->type=$type;
        $historial->peticion=$request->all();
        $historial->user=$user;
        $historial->dato=$dato;
        //$historial->date=date(DATE_RFC2822);
        $historial->date=Carbon::now()->toDateTimeString();
        array_push($historialList,$historial);

        //guardo historial
        $fp = fopen("historial.txt","w");//w trunca a 0 longitud
        fwrite($fp,json_encode($historialList));
        fclose($fp);

        return "guardado correctamente";
}


    public function isExistinArray(User $user,$array){
        foreach ($array as &$usersRe) {
            //foreach ($this->users as &$usersSesion) {
               // if($user->compare($usersRe)){
                if($user->compare(new User($usersRe["name"],$usersRe["password"]))){
                   // $user->token=$usersRe->token;
                    //$user->timeVencimiento=$usersRe->timeVencimiento;
                    $user->token=$usersRe["token"];//asigno el token para generar un token unico despues
                    return $user;
                }
            }
            return false;
    }
    public function isSession($token){
        foreach ($_SESSION["users"] as &$usersSesion) {
        // foreach ($this->users as &$usersSesion) {
            if($token==$usersSesion->token){
                return $usersSesion;
                //return User::fromJson($usersSesion);
            }
        }
        return false;
    }
    

    //verifica tiempo si ya expiro, si expiro elimina la session
    public function verificarTime(){
        for($i = 0; $i < sizeof($_SESSION["users"]);$i++){
            if($_SESSION["users"][$i]->isExpired()){
                array_splice($_SESSION["users"], $i, 1);
            }
        }
        /*for($i = 0; $i < sizeof($this->users);$i++){
            if($this->users[$i]->isExpired()){
                array_splice($this->users, $i, 1);
            }
        }*/
        return true;
    }
    //obtengo todas las sesiones
    public function getSesions(){
        return json_encode($_SESSION["users"]);
       // return json_encode($_SESSION["users"]).(round(microtime(true) * 1000));
       // return json_encode($this->users).(round(microtime(true) * 1000));
    }

    public function getUsersFromtxt(){
        //tiene que estar el txt con un [] si o si sino da error
        /*try {
        $fp = fopen("users.txt","rw") or die('[]');
        $json =fgets($fp);
        fclose($fp);
        } catch (\Exception $e) {
           // $json="[]";
        }*/
        if(!file_exists("users.txt")){
            $fp = fopen("users.txt","w");
            fclose($fp);
        }
        $fp = fopen("users.txt","r") or die('[]');
        $json =fgets($fp);
        fclose($fp);
        if(empty($json))$json="[]";

        return json_decode($json,true);
    }
    public function saveUserstoTxt($users){
        $fp = fopen("users.txt","w");
        fwrite($fp,json_encode($users));
        fclose($fp);
    }

}
