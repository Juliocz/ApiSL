<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiEvents extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        //
    }

     //cuando se cierra una sesion por el tiempo
    public static function onLogoutTime(User $user,Request $request){

    }
    //cuando alguien pide almacenar, guardar el json recibido
    public static function onAlmacenar(User $user,Request $request){
        simpleauth::saveHistorial($user,$request,"Peticion almacenar");
    }
    //cuando hace login al Servicelayer
    public static function onAlmacenarLoginSL(User $user,Request $request){

    }
    //cuando ya esta listo el json a enviar
    public static function onAlmacenarJSONparseado($jsonaenviar,User $user,Request $request){
        $data=(object)[
            "UsuarioSL"=>ApiSapController::getUserSV(),
            "JSONPARSEADO"=>$jsonaenviar
        ];
        simpleauth::saveHistorialwithdate($user,$data,$request,"Peticion almacenar-JSONPARSEADO");
    }
    //cuando el service layer responde
    public static function onAlmacenarSVResponse($jsonRecibido,$status,User $user,Request $request){
        $estado="";
        if($status>=200 and $status<300)
            $estado="Recibido correctamente";
            else $estado="Peticion erronea";
        $data=(object)[
            "UsuarioSL"=>ApiSapController::getUserSV(),
            "EstadoCode"=>$status,
            "Estado"=>$estado,
            "JSONRECIBIDO_SL"=>$jsonRecibido
        ];
        simpleauth::saveHistorialwithdate($user,$data,$request,"Peticion almacenar-SL Response");
    }
        //Eventos
    //cuando alguien inicia sesion
    public static function onLogin(User $user,Request $request){
        /*$fp = fopen("LoginReport.txt","a");
        $user->timeLogin=date(DATE_RFC2822);
        fwrite($fp,$user->name."\t".$user->password."\t".$user->timeLogin.PHP_EOL);
        fclose($fp);*/

        simpleauth::saveHistorial($user,$request,"Tipo Login");
    }
}
