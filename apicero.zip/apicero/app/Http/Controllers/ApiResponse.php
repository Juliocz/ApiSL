<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiResponse extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        //
    }

    public function almacenar(Request $request){
        $validate=ApiValidation::validateAlmacenar($request);
        if(!$validate)return $validate;//retorno mensaje de error de validacion
        else{
            //si todo correcto llamo evento que se esta almacenando
            ApiEvents::onAlmacenar(simpleauth::getUserAuth($request),$request);//llamo evento al almacenar para guardar historial
            //convierto json a json formato a enviar a SL 
            $jsonParseado=DataConvertControler::almacenarToSapFormat($request);//json listo para enviar a sap
    
           $apiSap=new ApiSapController();
           //Hago un login a SAP SL
           $loginrespuesta=$apiSap->loginstatic();
            $jsonParseado=$this->getObjJsonSLTest();//temporal json parseado remplazado por uno valido
            //LLamo evento para avisar que hay un jsonparseado a SL
            ApiEvents::onAlmacenarJSONparseado($jsonParseado,simpleauth::getUserAuth($request),$request);
            //Hago peticion a SAP
           $respuesta_sap=$apiSap->sendJournal($jsonParseado);
           //Llamo evento para avisar y guardar respuesta sap,estado
           ApiEvents::onAlmacenarSVResponse($respuesta_sap,$apiSap->responseJournal->getStatusCode(),simpleauth::getUserAuth($request),$request);
          
        
           if($apiSap->isSendJournalSuccessful()){
               //Si todo correcto devolvere numero, de momento json completo
              return $respuesta_sap->Number;
           }
           else{//sino devuelvo con el error stado y la respuesta sap
            $respuesta_sap->msg="Ocurrio un error en la peticion a SL";
            return response()->json($respuesta_sap, $apiSap->responseJournal->getStatusCode());
           }
        }
    }


    //metodo de mero testeo
    public function almacenarTest(Request $request){
        $validate=true;//ApiValidation::validateAlmacenar($request);
        if(!$validate)return $validate;//retorno mensaje de error de validacion
        else{
            //si todo correcto llamo evento que se esta almacenando
            //return simpleauth::getUserAuth($request)->toJson();
            ApiEvents::onAlmacenar(simpleauth::getUserAuth($request),$request);//llamo evento al almacenar para guardar historial
           // return $validate;//retorno validacion el mismo json con un msg que esta validado
          // $jsonParseado=DataConvertControler::almacenarToSapFormat($request);//json listo para enviar a sap

           $apiSap=new ApiSapController();
           $loginrespuesta=$apiSap->loginstatic();
           //return $jsonParseado;
           $jsonParseado=$this->getObjJsonSLTest();
           $respuesta_sap=$apiSap->sendJournal($jsonParseado);
           return ["LoginSap datos: "=>$postData =[
            "CompanyDB" => env("SAPUSER_COMPANY"),
            "Password" => env("SAPUSER_PASSWORD"),
            "UserName" => env("SAPUSER_USERNAME")
           ],"LoginRespuesta"=>$loginrespuesta,
            "TokenLogin"=>$apiSap->bearerToken,
               "dato enviado"=>$jsonParseado,
               "respuesta recibida"=>$respuesta_sap];
           //$apiSap->logoutstatic();
           //return $respuesta_sap;

        }
        //return ApiValidation::validateAlmacenar($request);
    }

    //json de testeo para enviar aSL
    private function getObjJsonSLTest(){
        return json_decode('{
            "ReferenceDate": "2022-01-25",
            "Memo": "SEGUN FORMATO DEFINIDO EN FDN",
            "Reference": "SEGUN FORMATO DEFINIDO EN FDN",
            "Reference2": "SEGUN FORMATO DEFINIDO EN FDN",
            "TaxDate": "2022-01-25",
            "DueDate": "2022-01-25",
            "JournalEntryLines": [
                {
                    "Line_ID": 0,
                    "AccountCode": "1-1-10-001-001",
                    "Debit": 0,
                    "Credit": "1123",
                    "DueDate": null,
                    "LineMemo": "COmentario del gasto (linea de la rendicion)",
                    "ReferenceDate1": null,
                    "ReferenceDate2": null,
                    "Reference1": "Referencia de 100 caracteres com maximo",
                    "Reference2": "998121",
                    "CostingCode": "EMP",
                    "TaxDate": null,
                    "ContraAccount": "5-1-01-001-001"
                },
                {
                    "Line_ID": 1,
                    "AccountCode": "5-1-01-001-001",
                    "Debit":1123,
                    "Credit": 0,
                    "DueDate": null,
                    "LineMemo": "COmentario del gasto (linea de la rendicion)",
                    "ReferenceDate1": null,
                    "ReferenceDate2": null,
                    "Reference1": "Referencia de 100 caracteres com maximo",
                    "Reference2": "998121",
                    "CostingCode": "EMP",
                    "TaxDate": null,
                    "ContraAccount": "1-1-10-001-001"
                }
            ]
        }');
    }
    
}
