<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class User
{

    public $name;
    public $password;
    public $token;
    public $timeVencimiento;
    public function __construct($na,$pass)
    {
        $this->password = $pass;
        $this->name = $na;
    }
    /*public static function fromJson($user){
        $us=new User($user->name,$user->password);
        $us->token=$user->token;
        return $us;
    }*/
    public function toJson(){
        return json_encode($this);
    }
    public function getToken(){
        return $this->token;
    }
    public function compare(User $user){
        if($this->password==$user->password && $this->name==$user->name)
        return true;
        else return false;
    }
    
    //verifica si ya expiro
    public function isExpired(){
        if((round(microtime(true) * 1000))>$this->timeVencimiento)
            return true;
        else return false;
    }
}


