<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use stdClass;

class DataConvertControler extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        //´´´´
    }

    public static function almacenarToSapFormat(Request $request){
       
        //$sapJson=new stdClass();
        $sapJson=(object)[
            "ReferenceDate"=>$request->RefDate,
            "Memo"=>$request->Memo,
            "Reference"=> $request->Memo,
            "Reference2"=> $request->Memo,
            "TaxDate"=> $request->TaxDate,
            "DueDate"=> $request->DueDate,
            "JournalEntryLines"=>array()
        ];
        //$reques=json_decode($request->json());
        //return sizeof($request->Detalle);
        $index=0;
        //$sapJson->JournalEntryLines=$request->Detalle;
        foreach ($request->Detalle as $detalle) {
            $detalle=json_encode($detalle);
            $detalle=json_decode($detalle);
            $journalDetalle=[
                "Line_ID"=>$index,
                //"AccountCode"=>$detalle["OACT_AccountCode"]/*,
                "AccountCode"=>$detalle->OACT_AccountCode,
                "Debit"=>$detalle->JDT1_Debit,
                "Credit"=>$detalle->JDT1_Credit,
                //"DueDate"=>$sapJson->DueDate,
                "DueDate"=>null,
                //"ContraAccount"=>: "1-1-01-001-004",
                "LineMemo"=>$detalle->JDT1_LineMemo,
                "ReferenceDate1"=>null,
                "ReferenceDate2"=>null,
                "Reference1"=>$detalle->JDT1_Ref1,
                "Reference2"=>$detalle->JDT1_Ref2,
                "CostingCode"=>$detalle->JDT1_ProfitCode,
                "TaxDate"=>null,
                "ContraAccount"=>"1-1-10-001-001"
            ];
            array_push($sapJson->JournalEntryLines,$journalDetalle);
            //array_push($sapJson['JournalEntryLines'],$journalDetalle);
            $index++;    
        }
        return $sapJson;
    }
        
}
