<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use stdClass;

//include('vendor/rmccue/requests/library/Requests.php');

class ApiSapController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

     public $bearerToken;
    public function __invoke(Request $request)
    {
        //
    }


    //HACE LOGIN ESTATICO A SAP con parametros del env, y devuelve la sesion id el cual se usara en bearer token luego
    public function loginstatic(){
        $postData =[
            "CompanyDB" => env("SAPUSER_COMPANY"),
            "Password" => env("SAPUSER_PASSWORD"),
            "UserName" => env("SAPUSER_USERNAME")
        ];
       /* $opciones = array(
            "http" => array(
                "header" => "Content-type: application/json\r\n",
                "method" => "GET",
                "content" => json_encode($postData), # Agregar el contenido definido antes
            )
        );
        # Preparar petición
        $contexto = stream_context_create($opciones);*/
        $respuesta=json_decode(Http::withoutVerifying()->post(env('HOSTSAPLOGIN'),$postData)->body());
        $this->bearerToken=$respuesta->SessionId;
        return $respuesta; 
    }
    public function logoutstatic(){
        $postData =[
            "CompanyDB" => env("SAPUSER_COMPANY"),
            "Password" => env("SAPUSER_PASSWORD"),
            "UserName" => env("SAPUSER_USERNAME")
        ];
        $opciones = array(
            "http" => array(
                "header" => "Content-type: application/json\r\n",
                "method" => "GET",
                "content" => json_encode($postData), # Agregar el contenido definido antes
            )
        );
        # Preparar petición
        $contexto = stream_context_create($opciones);
        return json_decode(Http::withoutVerifying()->post(env('HOSTSAPLOGOUT'),$postData)->body());  
    }

    public static function getUserSV(){
        return $postData =(object)[
            "CompanyDB" => env("SAPUSER_COMPANY"),
            "Password" => env("SAPUSER_PASSWORD"),
            "UserName" => env("SAPUSER_USERNAME")
        ];
        
    }


    public function login(Request $request){
        $postData =[
            "CompanyDB" => $request->CompanyDB,
            "Password" => $request->Password,
            "UserName" => $request->UserName
        ];
 
        // Crear opciones de la petición HTTP
        $opciones = array(
            "http" => array(
                "header" => "Content-type: application/json\r\n",
                "method" => "GET",
                "content" => json_encode($postData), # Agregar el contenido definido antes
            )
           /* 'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )*/
        );
        # Preparar petición
        $contexto = stream_context_create($opciones);
        # Hacerla
        //$resultado = file_get_contents(/*env('HOSTSAPLOGIN')*/"http://www.google.com", false, $contexto);
        //    $resultado= http_get("https://www.example.com/", array("timeout"=>1), $info);
        return json_decode(Http::withoutVerifying()->post(env('HOSTSAPLOGIN'),$postData)->body()); 
            /*if ($resultado === false) {
            return "Error en la peticion a SAP";
        }
        else return $resultado;*/



        /*$responsePost = Requests::post(env('HOSTSAPLOGIN'), null, $postData);
        return json_encode($responsePost);*/
    }

    public $responseJournal;
    //envia json y recibe json en object
    public function sendJournal($journalData){
        $this->responseJournal=Http::withoutVerifying()
        ->withToken($this->bearerToken)
        ->withHeaders([
            "Cookie"=>"B1SESSION=".$this->bearerToken
        ])
        ->post(env('HOSTSAPJOURNAL'),json_decode(json_encode($journalData), true));
        return json_decode($this->responseJournal->body()); 
    }
    //este metodo solo se puede usar despues de enviar un jorunal, por que sino es nulo
    public function isSendJournalSuccessful(){
        if($this->responseJournal->successful())return true;
        else return $this->responseJournal->getStatusCode();
    }

   /* public function sendJournal($journalData){
        
        return json_decode(Http::withoutVerifying()
        ->withToken($this->bearerToken)
        //->withCookies([cookie()->forever('BS1', $this->bearerToken)],"HttpOnly")
        //->withHeaders(['Coockie'=>"B1SESSION=c7f59170-7ed8-11ec-8000-005056bf67ef; ROUTEID=.node6"])
        ->withHeaders([
            "Cookie"=>"B1SESSION=".$this->bearerToken
        ])
        //->withCookies(["B1SESSION"=>$this->bearerToken],"")
        ->post(env('HOSTSAPJOURNAL'),json_decode(json_encode($journalData), true))//el json encode y decode es por que necesita un array que obtenga datos asi $obj["atributo"]... y lo que yo le pase es un objeto
        ->body()); 
    }*/
}
