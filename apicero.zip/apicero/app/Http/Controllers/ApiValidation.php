<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use stdClass;

class ApiValidation extends Controller
{
    protected static $rules = [
        "RefDate"=> "required|min:5|max:255",
        "DueDate"=> "required|min:5|max:255",
        "TaxDate"=> "required|min:5|max:255",
        "Memo"=> "required|min:2|max:50",
        "Detalle"=>'required|array|between:1,1000',//Detalle tiene que ser un vector tamaño minimo y maximo
            'Detalle.*.OACT_AccountCode' => "required|min:1|max:50",
            'Detalle.*.OACT_AccountName' => "required|min:1|max:100",
            'Detalle.*.JDT1_Debit' => "required|max:61",
            'Detalle.*.JDT1_Credit' => "required|max:60",
            'Detalle.*.JDT1_LineMemo' => "required|min:1|max:50",
            'Detalle.*.JDT1_ProfitCode' => "required|min:1|max:8",
            'Detalle.*.JDT1_Ref1' => "required|min:1|max:100",
            'Detalle.*.JDT1_Ref2' => "required|min:1|max:100",
            'Detalle.*.JDT1_Ref3' => "required|min:1|max:100"
           // 'Detalle.*.quantity' => 'required|numeric',
    ];
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        //
    }
    //valida asiento contable , datos y vector detalle
    //si algo esta mal devuelve mensaje error, si esta bien devuelve true o sino devolera un objeto con los valores
    public static function validateAlmacenar(Request $request){
       
        $validator = validator($request->all(), 
            self::$rules
        );
        if($validator->fails())
            //return "validacion fallida";
            return $validator->errors()->toJson();
            //else return $request->all();//todo el body recibido
            else {
                $r=new stdClass();
                $r->AsientoContable=$request->all();
                $r->Msg="Validacion exitosa";
                //return $r;
                return $r;
                //return "Validacion exitosa";
            }
            //else return $request->name;//un parametro del body en json, aunque esto tambien me da la impresion que puede obtener xml automatic u otro compatible
    }
}
