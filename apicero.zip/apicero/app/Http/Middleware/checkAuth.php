<?php

namespace App\Http\Middleware;

use App\Http\Controllers\simpleauth;
use Closure;
use Illuminate\Http\Request;

class checkAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {   
        //return response($request->bearerToken());
        //return $request->cookie(simpleauth::$coockieTokenName);
        $auth=new simpleauth($request);
        $token=$request->bearerToken();
        if(!$token)$token=$request->cookie(simpleauth::$coockieTokenName);
        //return $auth->getSesions();
        if($auth->isSession($token))
        return $next($request);
        else 
        return redirect("/");

        //return $request->header('Authorization');
    }
}
